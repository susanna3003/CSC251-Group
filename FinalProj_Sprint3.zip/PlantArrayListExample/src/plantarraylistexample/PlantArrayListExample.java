/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package plantarraylistexample;

/**
 *
 * @author quayles5806
 */
import java.util.ArrayList;
import javax.swing.JOptionPane;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JFrame;

public class PlantArrayListExample
{
   // TODO: Define a printArrayList method that prints an ArrayList of plant (or flower) objects   
    
   public static ArrayList<Plant> createArrayList(){
       // TODO: Declare an ArrayList called myGarden that can hold object of type plant
      ArrayList<Plant> myGarden = new ArrayList<>();

      // TODO: Declare variables - plantName, plantCost, flowerName, flowerCost, colorOfFlowers, isAnnual
      String plantName;
      String plantCost;
      String flowerName;
      String flowerCost;
      String colorOfFlowers;
      int annual;

      int userChoice;
      String[] yOrN = {"yes", "no"};
      userChoice = JOptionPane.showOptionDialog(null, "Would you like to enter a plant?", "Select one: ", 0, 2, null, yOrN, yOrN[0]);
      
      do 
      {
         // TODO: Check if input is a plant or flower
         //       Store as a plant object or flower object
         //       Add to the ArrayList myGarden
        String[] options = {"plant", "flower"};
        int choice = JOptionPane.showOptionDialog(null, "What kind of plant?", "Select one: ", 0, 2, null, options, options[0]);
         
         if (choice == 0) 
         {
            Plant newPlant = new Plant();
          
            plantName = JOptionPane.showInputDialog("What is the plant name?");
            plantCost = JOptionPane.showInputDialog("What is the plant cost?");
            newPlant.setPlantName(plantName);
            newPlant.setPlantCost(plantCost);
            
            myGarden.add(newPlant);
            userChoice = JOptionPane.showOptionDialog(null, "Would you like to enter a plant?", "Select one: ", 0, 2, null, yOrN, yOrN[0]);
         }
         else if (choice == 1) 
         {
            Flower newFlower = new Flower();
            
            flowerName = JOptionPane.showInputDialog("What is the flower name?");
            flowerCost = JOptionPane.showInputDialog("What is the flower cost?");
            
            // create frame for yes/no joptionpane for annual
            JFrame frame = new JFrame();
            Object stringArray[] = {"Yes", "No"};
            Icon blueIcon = new ImageIcon("");
            annual = JOptionPane.showOptionDialog(frame, "Is this flower annual or no?", "Select an Option", JOptionPane.YES_NO_OPTION, 
                JOptionPane.QUESTION_MESSAGE, blueIcon, stringArray,
            stringArray[0]);
            colorOfFlowers = JOptionPane.showInputDialog("What color are the flowers?");
            
            //Boolean isAnnual = Boolean.parseBoolean(annual);
            
            newFlower.setPlantName(flowerName);
            newFlower.setPlantCost(flowerCost);
            newFlower.setPlantType(annual);
            newFlower.setColorOfFlowers(colorOfFlowers);
            
            myGarden.add(newFlower);
            userChoice = JOptionPane.showOptionDialog(null, "Would you like to enter a plant?", "Select one: ", 0, 2, null, yOrN, yOrN[0]);
        }     
      } while (userChoice != 1);
      return myGarden;
   }
   
   
   public static void AddToFrame(ArrayList<Plant> myGarden)
   {
       int i;
       
        // where we will create and call the frame
        Frame frame = new Frame();
        frame.setSize(350,350);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setVisible(true);   
        JOptionPane.showMessageDialog(frame, "plant information goes here","Plant Info", JOptionPane.PLAIN_MESSAGE);
        
        for (i = 0; i < myGarden.size(); ++i) 
        {
         frame.outputArea.append("Plant " + (i+1) + " Information: ");
         frame.outputArea.append("\nPlant name: " + myGarden.get(i).getPlantName());
         frame.outputArea.append("\nPlant cost: " + myGarden.get(i).getPlantCost());
         frame.outputArea.append("\n");
        }
   }
    public static void main(String[] args) 
    {
        ArrayList<Plant> myGarden = createArrayList();
        AddToFrame(myGarden);
    }
}