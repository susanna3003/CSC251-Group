/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package plantarraylistexample;

/**
 *
 * @author quayles5806
 */
public class Flower extends Plant {

   private int isAnnual;
   private String colorOfFlowers;

   public void setPlantType(int userIsAnnual) {
      isAnnual = userIsAnnual;
   }

   public int getPlantType(){
      return isAnnual;
   }

   public void setColorOfFlowers(String userColorOfFlowers) {
      colorOfFlowers = userColorOfFlowers;
   }

   public String getColorOfFlowers(){
      return colorOfFlowers;
   }
   
   @Override
   public void printInfo(){
      System.out.println("   Plant name: " + plantName);
      System.out.println("   Cost: " + plantCost);
      System.out.println("   Annual: " + isAnnual);
      System.out.println("   Color of flowers: " + colorOfFlowers);
   }
}