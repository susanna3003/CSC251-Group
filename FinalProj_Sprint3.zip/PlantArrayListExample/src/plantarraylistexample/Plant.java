/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package plantarraylistexample;

/**
 *
 * @author quayles5806
 */
public class Plant {
   protected String plantName;
   protected String plantCost;

   public void setPlantName(String userPlantName) {
      plantName = userPlantName;
   }

   public String getPlantName() {
      return plantName;
   }

   public void setPlantCost(String userPlantCost) {
      plantCost = userPlantCost;
   }

   public String getPlantCost() {
      return plantCost;
   }

   public void printInfo() {
      System.out.println("   Plant name: " + plantName);
      System.out.println("   Cost: " + plantCost);
   }
}