/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package arraylist_alnajarrana;

/**
 *
 * @author Rana
 */
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import javax.swing.JOptionPane;

public class ArrayList_AlnajarRana {

    private static final ArrayList<Plant> plantList = new ArrayList<Plant>();

    public static void main(String[] args) {
        boolean goAgain = true;

        while (goAgain) {
            String input;

            do {
                input = JOptionPane.showInputDialog("Enter a plant or flower (or 1 to exit):");

                if (input.equals("1")) {
                    JOptionPane.showMessageDialog(null, "Goodbye!");
                    goAgain = false; // Set goAgain to false to exit the loop
                    break;
                }

                // Check if the input is a plant or a flower
                if (input.equalsIgnoreCase("plant")) {
                    // If it's a plant, create a new Plant object
                    Plant plant = new Plant();
                    plant.setPlantName(JOptionPane.showInputDialog("Enter plant name: "));
                    plant.setPlantCost(JOptionPane.showInputDialog("Enter plant cost: "));
                    plantList.add(plant); // Add the plant to the ArrayList
                } else if (input.equalsIgnoreCase("flower")) {
                    // If it's a flower, create a new Flower object
                    Flower flower = new Flower();
                    flower.setPlantName(JOptionPane.showInputDialog("Enter flower name: "));
                    flower.setPlantCost(JOptionPane.showInputDialog("Enter flower cost: "));
                    boolean isAnnual = JOptionPane.showInputDialog("Is it an annual flower? (yes/no): ").equalsIgnoreCase("yes");
                    flower.setPlantType(isAnnual);
                    flower.setColorOfFlowers(JOptionPane.showInputDialog("Enter color of flowers: "));
                    plantList.add(flower); // Add the flower to the ArrayList
                } else {
                    JOptionPane.showMessageDialog(null, "Invalid input. Please enter 'plant' or 'flower'.");
                }
            } while (!input.equals("1"));

            // Call the method to print the ArrayList
            printArrayList(plantList);

            try {
                printPlantListFile();
            } catch (IOException e) {
            }

            int choice = JOptionPane.showConfirmDialog(null, "Do you want to go again?", "Go Again?", JOptionPane.YES_NO_OPTION);
            goAgain = (choice == JOptionPane.YES_OPTION);
            plantList.clear(); // Clear the list for the next session
        }
    }

    // Define a printArrayList method that prints an ArrayList of Plant objects
    public static void printArrayList(ArrayList<Plant> list) {
        StringBuilder listInfo = new StringBuilder();
        list.forEach((plant) -> {
            listInfo.append(plant.toString()).append("\n");
        });
        JOptionPane.showMessageDialog(null, listInfo.toString());
    }

    // Define a printPlantListFile method to write the list contents to a text file
    public static void printPlantListFile() throws IOException {
        try (PrintWriter outputFile = new PrintWriter("PlantList.txt")) {
            plantList.forEach((plant) -> {
                outputFile.println(plant.toString());
            });
        }
    }
}